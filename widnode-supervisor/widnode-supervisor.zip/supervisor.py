import os, sys, time, signal, subprocess, configparser
from pathlib import Path

# === GPIO y config ===
GPIOCHIP = os.getenv("GPIOCHIP", "/dev/gpiochip0")
GPIOLINE = os.getenv("GPIOLINE", "6")
CONFIG_PATH = os.getenv("CONFIG_PATH", "/data/config.ini")

ETH_IF = os.getenv("ETH_IF", "ethernet0")
WIFI_IF = os.getenv("WIFI_IF", "mlan0")

POLL_INTERVAL = float(os.getenv("POLL_INTERVAL_SEC", "1.0"))
DEBOUNCE_SAMPLES = int(os.getenv("DEBOUNCE_SAMPLES", "3"))
DEBOUNCE_DELAY = float(os.getenv("DEBOUNCE_DELAY_SEC", "0.1"))

RESTART_FLAG = Path("/data/restart.flag")

GPIO_HOLDOFF_S = 4  # segundos mínimos entre cambios de modo
_last_switch_ts = 0


# === AP: una sola vía: script dedicado que usa SÓLO variables de entorno ===
AP_CMD = "/opt/app/ap_stack.sh"

ap_proc = None
app_proc = None
current_mode = None  # "AP" | "CLIENT"

def check_restart_flag_and_exit_if_needed():
    if RESTART_FLAG.exists():
        try:
            RESTART_FLAG.unlink()
        except Exception:
            pass
        print("[CTRL] Restart solicitado por UI. Saliendo para que Compose reinicie el contenedor...")
        sys.stdout.flush()
        sys.exit(0)

# ---------- utils ----------
def sh(cmd):
    return subprocess.run(cmd, shell=True, check=False)

def out(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)

def gpioget_once():
    r = subprocess.run(["gpioget", GPIOCHIP, str(GPIOLINE)],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print(f"[ERR] gpioget fallo: {r.stderr.strip()}")
        return None
    try:
        return int(r.stdout.strip())
    except Exception:
        return None

def gpioget_debounced():
    vals = []
    for _ in range(DEBOUNCE_SAMPLES):
        v = gpioget_once()
        if v is not None:
            vals.append(v)
        time.sleep(DEBOUNCE_DELAY)
    if not vals:
        return None
    return 1 if sum(vals) >= (len(vals)/2.0) else 0

def load_cfg():
    cfg = configparser.RawConfigParser()
    cfg.read(CONFIG_PATH)
    return cfg

def ping_ok(host="8.8.8.8", count=3):
    return sh(f"ping -c {count} {host} >/dev/null 2>&1").returncode == 0

# ---------- Helpers de red ----------
def netmask_to_prefix(mask):
    try:
        bits = "".join([bin(int(octet))[2:].zfill(8) for octet in mask.split(".")])
        return str(bits.count("1"))
    except Exception:
        return "24"

# ---------- Ethernet ----------
def eth_down():
    sh("nmcli con down eth-client >/dev/null 2>&1 || true")
    sh("nmcli con delete eth-client >/dev/null 2>&1 || true")

def eth_up(cfg):
    if not cfg.getboolean("Ethernet", "enabled", fallback=False):
        print("[ETH] disabled -> skip")
        eth_down()
        return False

    method = cfg.get("Ethernet","mode", fallback=cfg.get("Ethernet","method", fallback="dhcp")).strip().lower()

    # soporta 'address' (CIDR) o 'ip_address' + 'netmask'
    address_cidr = cfg.get("Ethernet","address", fallback="").strip()
    ip_address   = cfg.get("Ethernet","ip_address", fallback="").strip()
    netmask      = cfg.get("Ethernet","netmask", fallback="255.255.255.0").strip()
    gateway      = cfg.get("Ethernet","gateway", fallback="").strip()
    dns          = cfg.get("Ethernet","dns",     fallback="").strip()

    if not address_cidr and ip_address:
        address_cidr = f"{ip_address}/{netmask_to_prefix(netmask)}"

    print(f"[ETH] Config: method={method} dev={ETH_IF}")
    sh(f"nmcli dev disconnect {ETH_IF} || true")
    eth_down()
    sh(f"nmcli con add type ethernet ifname {ETH_IF} con-name eth-client")

    if method == "static":
        if not address_cidr:
            print("[ETH][ERR] Falta 'ip_address'/'address'")
            return False
        sh("nmcli con modify eth-client ipv4.method manual")
        sh(f"nmcli con modify eth-client ipv4.addresses '{address_cidr}'")
        if gateway: sh(f"nmcli con modify eth-client ipv4.gateway '{gateway}'")
        if dns:     sh(f"nmcli con modify eth-client ipv4.dns '{dns}'")
    else:
        sh("nmcli con modify eth-client ipv4.method auto")

    sh("nmcli con modify eth-client connection.autoconnect yes")
    rc = sh("nmcli -w 20 con up eth-client").returncode
    if rc != 0:
        print("[ETH][ERR] Fallo al activar 'eth-client'")
        print(out(f"nmcli -t -f GENERAL.STATE,IP4.ADDRESS,IP4.GATEWAY device show {ETH_IF}").stdout)
        return False

    print("[ETH] Activo. Estado:")
    print(out(f"nmcli -t -f GENERAL.STATE,IP4.ADDRESS,IP4.GATEWAY device show {ETH_IF}").stdout)
    return True

# ---------- Wi-Fi ----------
# def wifi_down():
#     sh("nmcli con down wifi-client >/dev/null 2>&1 || true")
#     sh("nmcli con delete wifi-client >/dev/null 2>&1 || true")

def wifi_down():
    # Desactiva conexiones Wi-Fi cliente y suelta control de NM
    sh("nmcli -w 5 dev disconnect mlan0 || true")
    sh("nmcli -w 5 con down wifi-client || true")
    sh("nmcli -w 5 con down wifi-client-test || true")
    # Mata wpa_supplicant si quedó colgado (pkill si existe; si no, killall)
    sh("sh -c 'command -v pkill >/dev/null && pkill -f wpa_supplicant || killall -q wpa_supplicant || true'")
    sh("ip addr flush dev mlan0 || true")

def wifi_up(cfg):
    if not cfg.getboolean("WiFi", "enabled", fallback=False):
        print("[WiFi] disabled -> skip")
        wifi_down()
        return False

    ssid = cfg.get("WiFi", "ssid", fallback="").strip()
    psk  = cfg.get("WiFi", "password", fallback="").strip()
    if not ssid:
        print("[WiFi][ERR] SSID vacío")
        return False

    sh(f"nmcli dev disconnect {WIFI_IF} || true")
    wifi_down()
    sh(f"nmcli dev set {WIFI_IF} managed yes || true")
    sh(f"nmcli dev wifi rescan ifname {WIFI_IF} || true")

    if psk:
        cmd = f"nmcli -w 30 dev wifi connect '{ssid}' password '{psk}' ifname {WIFI_IF} name wifi-client"
    else:
        cmd = f"nmcli -w 30 dev wifi connect '{ssid}' ifname {WIFI_IF} name wifi-client"

    print(f"[WiFi] Conectando via: {cmd}")
    rc = sh(cmd).returncode
    if rc != 0:
        print("[WiFi][ERR] Fallo 'dev wifi connect'")
        print(out("nmcli -t device status").stdout)
        return False

    print("[WiFi] Activo. Estado mlan0:")
    print(out(f"nmcli -t -f GENERAL.STATE,IP4.ADDRESS,IP4.GATEWAY device show {WIFI_IF}").stdout)
    return True

# ---------- LTE ----------
def lte_down():
    sh("nmcli con down lte-client >/dev/null 2>&1 || true")
    sh("nmcli con delete lte-client >/dev/null 2>&1 || true")

def _lte_section(cfg):
    return "LTE-4G" if cfg.has_section("LTE-4G") else "LTE"

def lte_up(cfg):
    section = _lte_section(cfg)
    if not cfg.getboolean(section, "enabled", fallback=False):
        print("[LTE] disabled -> skip")
        lte_down()
        return False

    apn  = cfg.get(section,"apn",fallback="").strip()
    user = cfg.get(section,"user",fallback="").strip()
    pw   = cfg.get(section,"password",fallback="").strip()
    pin  = cfg.get(section,"pin",fallback="").strip()

    if not apn:
        print("[LTE][ERR] Falta APN")
        return False

    lte_down()
    sh("nmcli con add type gsm ifname '*' con-name lte-client apn '"+apn+"'")
    if user: sh("nmcli con modify lte-client gsm.username '"+user+"'")
    if pw:   sh("nmcli con modify lte-client gsm.password '"+pw+"'")
    sh("nmcli con modify lte-client connection.autoconnect yes")

    if pin:
        print("[LTE] Intentando desbloquear SIM con PIN")
        sh(f"mmcli -i 0 --pin={pin} >/dev/null 2>&1 || true")

    rc = sh("nmcli -w 40 con up lte-client").returncode
    if rc != 0:
        print("[LTE][ERR] Fallo al activar LTE")
        print(out("nmcli -t device status").stdout)
        return False

    print("[LTE] Activo. (ver conexiones activas para IP)")
    print(out("nmcli -t connection show --active | grep lte-client || true").stdout)
    return True

# ---------- App ----------
def _app_cmd_from_config():
    try:
        cfg = load_cfg()
        if cfg.has_section("APP"):
            cmd = cfg.get("APP","cmd", fallback="").strip()
            if cmd:
                return cmd
    except Exception:
        pass
    return os.getenv("APP_CMD", "python3 /opt/app/user_app.py").strip()

def run_user_app():
    cmd = _app_cmd_from_config()
    print(f"[APP] Lanzando: {cmd}")
    return subprocess.Popen(cmd, shell=True)

# ---------- Stacks ----------
def start_ap_stack():
    global ap_proc
    print("[STACK] Iniciando AP+UI")
    # 1) Cae todo lo "cliente"
    eth_down(); wifi_down(); lte_down()
    # 2) Evita que NM interfiera con el Wi-Fi mientras está el AP
    sh(f"nmcli dev set {WIFI_IF} managed no || true")
    # 3) (extra seguridad) limpia y sube uap0 antes de lanzar el stack
    sh("ip link set uap0 down || true")
    sh("ip addr flush dev uap0 || true")
    sh("ip link set uap0 up || true")
    # 4) Lanza el stack en su propio *process group* para poder matarlo en bloque
    ap_proc = subprocess.Popen(AP_CMD, shell=True, preexec_fn=os.setsid)
    time.sleep(2)
    return True

def stop_ap_stack():
    global ap_proc
    print("[STACK] Deteniendo AP+UI")
    try:
        if ap_proc and ap_proc.poll() is None:
            os.killpg(os.getpgid(ap_proc.pid), signal.SIGTERM)
            time.sleep(1)
            os.killpg(os.getpgid(ap_proc.pid), signal.SIGKILL)
    except Exception as e:
        print(f"[AP] WARN killpg: {e}")
    finally:
        ap_proc = None

    # Plan B: por si hostapd -B se despegó o dnsmasq dejó hijos
    sh("sh -c 'command -v pkill >/dev/null && pkill -9 hostapd dnsmasq || killall -q hostapd dnsmasq || true'")

    # Baja y limpia uap0
    sh("ip link set uap0 down || true")
    sh("ip addr flush dev uap0 || true")

    # Vuelve a dejar mlan0 manejado por NM
    sh("nmcli dev set mlan0 managed yes || true")


def start_client_stack():
    cfg = load_cfg()
    ok = False
    print("[STACK] Cliente: prioridad ETH→WiFi→LTE")
    if eth_up(cfg): ok = True
    elif wifi_up(cfg): ok = True
    elif lte_up(cfg): ok = True

    if not ok:
        print("[STACK][ERR] No hubo conectividad")
        return False, None

    if ping_ok():
        print("[NET] Conectividad OK (ping 8.8.8.8).")
    else:
        print("[NET][WARN] Sin ICMP a 8.8.8.8.")

    proc = run_user_app()
    return True, proc

def stop_client_stack():
    global app_proc
    print("[STACK] Deteniendo Cliente (app + perfiles)")
    if app_proc and app_proc.poll() is not None:
        app_proc = None
    if app_proc and app_proc.poll() is None:
        app_proc.terminate()
        try:
            app_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            print("[APP][WARN] kill()")
            app_proc.kill()
            app_proc.wait()
    app_proc = None
    eth_down(); wifi_down(); lte_down()

# ---------- Señales ----------
def cleanup(*_):
    stop_client_stack()
    stop_ap_stack()
    sys.exit(0)

# ---------- Main loop ----------
def main():
    global current_mode, ap_proc, app_proc
    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    v0 = gpioget_debounced()
    if v0 is None:
        print("[FATAL] No puedo leer GPIO (arranque).")
        sys.exit(1)
    print(f"[GPIO] Estado inicial {GPIOCHIP} line {GPIOLINE} => {v0}")
    desired = "AP" if v0 == 1 else "CLIENT"

    if desired == "AP":
        start_ap_stack()
    else:
        ok, app_proc = start_client_stack()
        if not ok:
            print("[STACK] Cliente sin red: en espera…")
    current_mode = desired
    print(f"[MODE] Activo: {current_mode}")

    while True:
        check_restart_flag_and_exit_if_needed()
        time.sleep(POLL_INTERVAL)
        v = gpioget_debounced()
        if v is None:
            continue
        want = "AP" if v == 1 else "CLIENT"


        # --- HOLD-OFF anti rebote ---
        now = time.time()
        global _last_switch_ts
        if want != current_mode:
            if (now - _last_switch_ts) < GPIO_HOLDOFF_S:
                # Ignoro cambios demasiado rápidos
                continue

            print(f"[MODE] Transición solicitada por GPIO: {current_mode} -> {want}")
            if want == "AP":
                stop_client_stack()
                start_ap_stack()
            else:
                stop_ap_stack()
                ok, app_proc = start_client_stack()
                if not ok:
                    print("[STACK] Cliente sin red tras transición: en espera…")
            current_mode = want
            _last_switch_ts = now  # registro el último cambio

        # if want != current_mode:
        #     print(f"[MODE] Transición solicitada por GPIO: {current_mode} -> {want}")
        #     if want == "AP":
        #         stop_client_stack()
        #         start_ap_stack()
        #     else:
        #         stop_ap_stack()
        #         ok, app_proc = start_client_stack()
        #         if not ok:
        #             print("[STACK] Cliente sin red tras transición: en espera…")
        #     current_mode = want

        # # Si la app murió, no la relanzamos automáticamente (política conservadora)
        # if current_mode == "CLIENT" and app_proc and app_proc.poll() is not None:
        #     print(f"[APP][WARN] Proceso terminó rc={app_proc.returncode}. No relanzo (espera).")
        #     app_proc = None

if __name__ == "__main__":
    main()
