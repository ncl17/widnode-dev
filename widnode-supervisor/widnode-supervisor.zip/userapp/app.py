from utils import get_modbus_server_config, getMacBluetooth, restart_bluetooth, get_ip_addresses,get_api_server_address,detectar_nodo_ocupado,node_busy
from widnode_signal import descomponer_medicion, descomponer_medicion_ext
from command_process import execute_scheduled_tasks
import httpx
from dotenv import load_dotenv
import subprocess
import os
import time
import binascii
import logging
import base64
import struct
import datetime
import asyncio
import numpy as np
import json,gzip
from typing import Optional
from bleak import BleakScanner, BleakClient, BleakError
import psycopg2
import math
import uuid
from sdnotify import SystemdNotifier
from modbus_server import GatewayModbusServer, Map

# --- Agent BlueZ (dbus-next)
from dbus_next.aio import MessageBus
from dbus_next import BusType, Message, MessageType, Variant
from dbus_next.service import ServiceInterface, method
from dbus_next.errors import DBusError

# ============================================================
# BlueZ Agent para Passkey fijo (LESC Passkey Entry automático)
# ============================================================
AGENT_PATH = "/com/widnode/BLEAgent"
CAPABILITY = "KeyboardDisplay"  # Para que BlueZ llame RequestPasskey
BLUEZ_BUS = None  # se inicializa al registrar el agent


modbus_srv = None
widnode_modbus_index = {}
notifier: Optional[SystemdNotifier] = None

async def wait_event(event: asyncio.Event, total_timeout: float, tick: float = 10.0):
    """
    Espera un asyncio.Event con latidos intermedios al watchdog.
    Reemplaza a: await asyncio.wait_for(event.wait(), timeout=total_timeout)
    """
    global notifier
    loop = asyncio.get_running_loop()
    deadline = loop.time() + total_timeout
    while True:
        remaining = deadline - loop.time()
        if remaining <= 0:
            raise asyncio.TimeoutError()
        try:
            return await asyncio.wait_for(event.wait(), timeout=min(tick, remaining))
        except asyncio.TimeoutError:
            # Patea el watchdog y sigue esperando por otro 'tick'
            if notifier:
                notifier.notify("WATCHDOG=1")
            # cede el control al loop
            await asyncio.sleep(0)


async def get_modbus_index_for_widnode(widnode_id: str) -> int:
    """Consulta a backend /modbus_id/<widnode_id>. Devuelve 0 si no existe."""
    global cookies
    url = f"{API_URL}/widnodes/modbus_id/{widnode_id}"
    try:
        async with httpx.AsyncClient(cookies=cookies, timeout=15.0) as c:
            r = await c.get(url)
            if r.status_code == 200:
                return int(r.json().get("modbus_id", 0))
            return 0
    except Exception as e:
        logging.error(f"Error consultando modbus_id de {widnode_id}: {e}")
        return 0
    
def _get_default_pin():
    import os
    # Lee de entorno; si no está, usa 483729
    return int(os.getenv("WIDNODE_DEFAULT_PIN", "483729"))

class BLEAgent(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.Agent1")

    @method()  # legacy pairing (string)
    def RequestPinCode(self, device: "o") -> "s":
        pin = f"{_get_default_pin():06d}"
        logging.info(f"[AGENT] RequestPinCode {device} -> {pin}")
        return pin

    @method()
    def DisplayPinCode(self, device: "o", pincode: "s"):
        logging.info(f"[AGENT] DisplayPinCode {device}: {pincode}")

    @method()  # LESC (uint32)
    def RequestPasskey(self, device: "o") -> "u":
        pin_val = int(_get_default_pin())
        logging.info(f"[AGENT] RequestPasskey {device}")
        return pin_val

    @method()
    def DisplayPasskey(self, device: "o", passkey: "u", entered: "q"):
        logging.info(f"[AGENT] DisplayPasskey {device}: {passkey:06d} (entered={entered})")

    @method()  # Numeric comparison: NO lo usamos; rechazamos para forzar passkey
    def RequestConfirmation(self, device: "o", passkey: "u"):
        logging.warning(f"[AGENT] RequestConfirmation {device} {passkey:06d} -> Rejected")
        raise DBusError("org.bluez.Error.Rejected", "Numeric comparison no soportado")

    @method()
    def RequestAuthorization(self, device: "o"):
        logging.info(f"[AGENT] RequestAuthorization {device} -> OK")
        return

    @method()
    def AuthorizeService(self, device: "o", uuid: "s"):
        logging.info(f"[AGENT] AuthorizeService {device}, uuid={uuid} -> OK")
        return

    @method()
    def Cancel(self):
        logging.info("[AGENT] Cancel")

async def _dbus_call(bus: MessageBus, dest: str, path: str, iface: str, member: str,
                     signature: str = "", body=None):
    if body is None:
        body = []
    msg = Message(destination=dest, path=path, interface=iface, member=member,
                  signature=signature, body=body)
    reply = await bus.call(msg)
    if reply.message_type == MessageType.ERROR:
        raise DBusError(reply.error_name or "org.bluez.Error.Failed",
                        reply.body[0] if reply.body else "")
    return reply

async def start_bt_agent():
    """
    Conecta al system bus, exporta el Agent y lo registra como Default.
    Llamar una sola vez al inicio del programa.
    """
    global BLUEZ_BUS
    if BLUEZ_BUS is not None:
        return  # ya iniciado

    BLUEZ_BUS = await MessageBus(bus_type=BusType.SYSTEM).connect()
    agent = BLEAgent()
    BLUEZ_BUS.export(AGENT_PATH, agent)

    # RegisterAgent + RequestDefaultAgent
    await _dbus_call(BLUEZ_BUS, "org.bluez", "/org/bluez",
                     "org.bluez.AgentManager1", "RegisterAgent",
                     "os", [AGENT_PATH, CAPABILITY])
    await _dbus_call(BLUEZ_BUS, "org.bluez", "/org/bluez",
                     "org.bluez.AgentManager1", "RequestDefaultAgent",
                     "o", [AGENT_PATH])
    # logging.info(f"[AGENT] Registrado en {AGENT_PATH} como Default (cap={CAPABILITY}). "
    #              f"PIN={_get_default_pin():06d}")

async def mark_trusted(mac_address: str):
    """
    (Opcional) Marca un dispositivo como Trusted al terminar el bonding.
    Lo llamamos luego de conectar con éxito, para que BlueZ recuerde el vínculo.
    """
    if not mac_address:
        return
    if not BLUEZ_BUS:
        return
    dev_path = f"/org/bluez/hci0/dev_{mac_address.replace(':', '_')}"
    try:
        await _dbus_call(BLUEZ_BUS, "org.bluez", dev_path,
                         "org.freedesktop.DBus.Properties", "Set",
                         "ssv", ["org.bluez.Device1", "Trusted", Variant('b', True)])
        logging.info(f"[AGENT] Device Trusted = True -> {mac_address}")
    except Exception as e:
        logging.warning(f"[AGENT] No se pudo marcar Trusted {mac_address}: {e}")

load_dotenv()

class WidnodeEvents:
    def __init__(self):
        self.msg_received_event = asyncio.Event()
        self.config_processed_event = asyncio.Event()
        self.error_status_processed_event = asyncio.Event()
        self.alarm_processed_event = asyncio.Event()
        self.measurements_processed_event = asyncio.Event()
        self.measurementsEX_processed_event = asyncio.Event()
        self.cmd_processed_event = asyncio.Event()
        self.rms_processed_event = asyncio.Event()
        self.rms_descargada_event = asyncio.Event()
        self.med_descargada_event = asyncio.Event()
        self.med_array_event = asyncio.Event()
        self.rms_mem_save_event = asyncio.Event()

events = WidnodeEvents()



PACKET_PAYLOAD = 238
HEADER_SIZE     = 17
# WRITE_CHAR_UUID = "0000FE42-8E22-4541-9D4C-21EDAE82ED19"
# NOTIFY_CHAR_UUID = "0000FE44-8E22-4541-9D4C-21EDAE82ED19"
WRITE_CHAR_UUID = os.getenv("WRITE_CHAR_UUID")
NOTIFY_CHAR_UUID = os.getenv("NOTIFY_CHAR_UUID")



# --- NUEVO: filtro por servicio y cache de RPA ---
WIDNODE_SERVICE_UUID = os.getenv("WIDNODE_SERVICE_UUID")  # opcional, ej: "0000fe42-8e22-4541-9d4c-21edae82ed19"
WIDNODE_NAME_PREFIX = os.getenv("WIDNODE_NAME_PREFIX", "")  # opcional, ej: "WIDNODE"
LAST_SEEN_FILE = os.getenv("LAST_SEEN_FILE", "/var/lib/widnode/last_seen_rpa.json")
_last_seen_map = {}

def _load_last_seen():
    global _last_seen_map
    try:
        os.makedirs(os.path.dirname(LAST_SEEN_FILE), exist_ok=True)
        if os.path.exists(LAST_SEEN_FILE):
            with open(LAST_SEEN_FILE, "r") as f:
                _last_seen_map = json.load(f)
        else:
            _last_seen_map = {}
    except Exception as e:
        logging.warning(f"No se pudo cargar LAST_SEEN_FILE: {e}")
        _last_seen_map = {}

def _save_last_seen():
    try:
        with open(LAST_SEEN_FILE, "w") as f:
            json.dump(_last_seen_map, f)
    except Exception as e:
        logging.warning(f"No se pudo guardar LAST_SEEN_FILE: {e}")

def get_cached_rpa(identity_mac: str) -> Optional[str]:
    return _last_seen_map.get(identity_mac)

def set_cached_rpa(identity_mac: str, rpa_mac: str):
    _last_seen_map[identity_mac] = rpa_mac
    _save_last_seen()


# CONFIG_FILE = "/home/widnode/dev/widnode_ap/config.ini"
CONFIG_FILE = os.getenv("CONFIG_FILE")

# API_URL="http://192.168.5.4:5008/api"
# API_URL="http://190.191.28.5:5008/api"
API_URL = get_api_server_address()

LOGIN_ENDPOINT = "/login/"


## COMANDOS ##
COMMAND_CONFIG = bytearray([0x49, 0x44, 0xCA])  # SOLICITA LA CONFIGURACION
COMMAND_ERROR_STATUS = bytearray([0x49, 0x44, 0x29])  # SOLICITA LA CONFIGURACION
# SOLICITA ARRAY DE ESTADO DE MEDICIONES
COMMAND_MED = bytearray([0x49, 0x44, 0xCC])
# SOLICITA DESCARGA DE MEDICION EXTENDIDA
COMMAND_MED_EXT = bytearray([0x49, 0x44, 0x60])
# SOLICITA TODAS LAS MEDICIONES GUARDADAS DE RMS
COMMAND_RMS = bytearray([0x49, 0x44, 0xDD])
# SOLICITA DESCARGA DE UNA MEDICION EN PARTICULAR
COMMAND_CE = bytearray([0x49, 0x44, 0xCE])
# MARCA LA MEDICION X COMO DESCARGADA
COMMAND_CF = bytearray([0x49, 0x44, 0xCF])
# MARCA LA MEDICION RMS X COMO DESCARGADA
COMMAND_DB = bytearray([0x49, 0x44, 0xDB])
# GUARDA LA STATUS RMS EN LA MEMORIA INTERNA
COMMAND_SAVE_RMS_MEM = bytearray([0x49, 0x44, 0x52])
# IDNODE_GET_STATE_ALARM OBTIENE EL ESTADO DE ALARMA DEL NODO
COMMAND_ALARM_STATE = bytearray([0x49, 0x44, 0x25])


## VARIABLES ##
medicion_descargada = True
fecha = datetime.datetime.now()
fecha_extendida = datetime.datetime.now()
rmsx = 0
rmsy = 0
rmsz = 0
temp = 0
sample_rate = 0
alarma = 0
cantidadMensajes = 0
cantidadMensajesRMS = 0
rmsx_vel = 0
rmsy_vel = 0
rmsz_vel = 0
alarma_vel = 0
idx_actual = 0
rms_idx_list = []
indices_para_marcar = []
rssi_device_connected = -1
command_id_actual = 0
buffer = bytearray(49152)
buffer_ext = bytearray(6000*PACKET_PAYLOAD)
msg_count = 0
TIMEOUT = 250
MAX_RETRIES = 3
SCAN_TIMEOUT = 60
TIMEOUT_DEVICE_PROCESS = 4000
TIME_TO_MARK_DOWNLOAD = 50
TIME_TO_SAVE_MEM = 10
hayComandos = False
token = 0
cookies = httpx.Cookies()
cantidad_byte_med_ext = 0

error_en_fecha = False
rms_download_active = False
MAX_WAIT_TIME_BUSY = 140

## EVENTOS DE CONTROL ##


# Configuración básica de logging
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S",
                    handlers=[
                        logging.FileHandler(
                            "/home/widnode/dev/widnode/log/widnode.log"),
                        logging.StreamHandler()])

# Establece el nivel de registro de httpx en WARNING para evitar logs de solicitudes HTTP
# logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpx").disabled = True

logging.info('....🚀widnode gateway start🚀....')



async def login(email, password):
    global cookies
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{API_URL}{LOGIN_ENDPOINT}",
                json={"email": email, "password": password},
            )
            if response.status_code == 200:
                data = response.json()
                access_token = data.get("access_token")
                logging.info("✔️ Login successful")
                # Establecer manualmente la cookie
                cookies.set("access_token_cookie", access_token)
                return data.get("access_token")
            else:
                logging.error(
                    f"🚨 Login failed: {response.status_code} - {response.text}")
                return None
    except Exception as e:
        logging.error(f"Exception during login: {e}")
        return None



async def find_device_by_address(target_address: str):
    """
    target_address = 'identidad' que trae tu API (puede ser Public/Static).
    1) Intenta por última RPA cacheada.
    2) Escanea con filtro por Service UUID (si está definido), admitiendo:
       - address == target_address (identidad)
       - address == cached_rpa
       - advertisement_data contiene WIDNODE_SERVICE_UUID (+ opcional nombre que matchee prefix)
    """
    found_device = None
    cached_rpa = get_cached_rpa(target_address)

    # 1) Fast path por última RPA
    if cached_rpa:
        try:
            dev = await BleakScanner.find_device_by_address(cached_rpa, timeout=5.0)
            if dev:
                logging.info(f"🔎 Usando RPA cacheada para {target_address}: {cached_rpa}")
                return dev
        except Exception as e:
            logging.debug(f"No se encontró por RPA cacheada {cached_rpa}: {e}")

    # 2) Escaneo con filtros
    def matches_service(ad):
        if not WIDNODE_SERVICE_UUID:
            return False
        try:
            su = ad.service_uuids or []
            return any(u.lower() == WIDNODE_SERVICE_UUID.lower() for u in su)
        except Exception:
            return False

    def name_ok(name: Optional[str]):
        if not WIDNODE_NAME_PREFIX:
            return True
        return (name or "").startswith(WIDNODE_NAME_PREFIX)

    async def detection_callback(device, advertisement_data):
        nonlocal found_device
        global rssi_device_connected
        addr = device.address
        name = device.name

        if addr == target_address or (cached_rpa and addr == cached_rpa):
            logging.info(f"----- Dispositivo {target_address} encontrado (addr match). RSSI: {advertisement_data.rssi}")
            rssi_device_connected = advertisement_data.rssi
            found_device = device
            return

        if matches_service(advertisement_data) and name_ok(name):
            logging.info(f"----- Dispositivo {target_address} probable por UUID/Name. Addr={addr}, RSSI={advertisement_data.rssi}")
            rssi_device_connected = advertisement_data.rssi
            found_device = device
            return

    # Intenta pasar filtro por service_uuids al scanner si está disponible
    scanner_kwargs = {"detection_callback": detection_callback}
    if WIDNODE_SERVICE_UUID:
        scanner_kwargs["service_uuids"] = [WIDNODE_SERVICE_UUID]
    scanner = BleakScanner(**scanner_kwargs)

    try:
        await scanner.start()
        for _ in range(SCAN_TIMEOUT * 10):
            if found_device:
                break
            await asyncio.sleep(0.1)
    finally:
        await scanner.stop()

    # Si encontramos, cacheamos su RPA para el futuro
    if found_device:
        try:
            set_cached_rpa(target_address, found_device.address)
        except Exception as e:
            logging.debug(f"No se pudo cachear RPA para {target_address}: {e}")

    return found_device

async def write_characteristic(client, char_uuid, data, max_retries=3):
    retries = 0
    while retries < max_retries:
        try:
            await client.write_gatt_char(char_uuid, data)
            # await write_characteristic(client, char_uuid, data)
            # logging.info(f"Escritura exitosa en la característica {char_uuid}")
            return True  # Salir si la escritura fue exitosa
        except BleakError as e:
            retries += 1
            msg = str(e)
            logging.error(f"🚨 Error al escribir en {char_uuid}: {e}")
            if ("Service Discovery has not been performed" in msg) or ("Not connected" in msg):
                try:
                    if getattr(client, "is_connected", False):
                        # 1) Intento de rediscovery
                        try:
                            # Bleak >=0.22: get_services(force_update=True); si no, sin arg.
                            await client.get_services()
                        except TypeError:
                            await client.get_services()
                    # Si no está conectado, devolvemos False para que el caller decida reconectar
                except Exception as rec_e:
                    logging.debug(f"⚠️ Falló intento de rediscovery: {rec_e}")
            logging.info(f"🔂 Reintentando... ({retries}/{max_retries})")
            await asyncio.sleep(1)  # Espera un segundo antes de reintentar
        except Exception as e:
            logging.error(
                f"🚨 Error inesperado al escribir en {char_uuid}: {e}")
            break  # Salir del bucle en caso de un error inesperado

    logging.error(
        f"🚨 No se pudo escribir en la característica {char_uuid} después de {max_retries} intentos")
    return False


async def setTime_device(client):
    current_time = datetime.datetime.now()

    year = current_time.year - 2000
    month = current_time.month
    day = current_time.day

    hours = current_time.hour
    minutes = current_time.minute
    seconds = current_time.second+1
    day_of_week = (current_time.weekday() + 1) % 7

    TIMECOMMAND = bytearray(
        [0x49, 0x44, 0xd6, year, month, day, hours, minutes, seconds, day_of_week])
    # await client.write_gatt_char(WRITE_CHAR_UUID, TIMECOMMAND)
    await write_characteristic(client, WRITE_CHAR_UUID, TIMECOMMAND)
    logging.info("----- 🗓️ Sincronizando fecha")


async def configure_device(client):
    events.config_processed_event.clear()
    # await client.write_gatt_char(WRITE_CHAR_UUID, COMMAND_CONFIG)
    await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_CONFIG)
    logging.info("----- 🔧 Solicitando configuración")
    try:
        # await asyncio.wait_for(events.config_processed_event.wait(), timeout=6)
        await wait_event(events.config_processed_event, 6)
    except asyncio.TimeoutError:
        logging.error("***** ⚠️ Timeout Solicitando configuración.")
        events.config_processed_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(
            f"***** 🚨 Error inesperado Solicitando configuración: {e}")
        events.config_processed_event.set()  # Establece el evento en caso de error

async def get_error_status_device(client):
    events.error_status_processed_event.clear()
    # await client.write_gatt_char(WRITE_CHAR_UUID, COMMAND_CONFIG)
    await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_ERROR_STATUS)
    logging.info("----- 🔧 Solicitando error status")
    try:
        # await asyncio.wait_for(events.error_status_processed_event.wait(), timeout=5)
        await wait_event(events.error_status_processed_event, 5)
    except asyncio.TimeoutError:
        logging.error("***** ⚠️ Timeout Solicitando error status.")
        events.error_status_processed_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(
            f"***** 🚨 Error inesperado Solicitando error status: {e}")
        events.error_status_processed_event.set()  # Establece el evento en caso de error


async def update_alarm(client):
    events.alarm_processed_event.clear()

    await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_ALARM_STATE)
    logging.info("----- 🧾 Solicitando Estado de Alarmas")
    try:
        # await asyncio.wait_for(events.alarm_processed_event.wait(), timeout=10)
        await wait_event(events.alarm_processed_event, 10)
    except asyncio.TimeoutError:
        logging.error("***** ⚠️Timeout Solicitando Estado de Alarmas")
        events.alarm_processed_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(
            f"***** 🚨 Error inesperado Solicitando Estado de Alarmas: {e}")
        events.alarm_processed_event.set()  # Establece el evento en caso de error


async def download_rms(client):
    global rms_download_active
    rms_download_active = True
    rms_idx_list.clear()

    events.rms_processed_event.clear()
    await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_RMS)
    logging.info("----- 🧾 Solicitando RMS guardadas")
    try:
        # await asyncio.wait_for(events.rms_processed_event.wait(), timeout=290)
        await wait_event(events.rms_processed_event, 290)
    except asyncio.TimeoutError:
        logging.error("***** ⚠️ Timeout Solicitando RMS guardadas")
        rms_download_active = False
        events.rms_processed_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(
            f"***** 🚨 Error inesperado Solicitando RMS guardadas: {e}")
        rms_download_active = False
        events.rms_processed_event.set()  # Establece el evento en caso de error


async def mark_rms_downloaded(client, rms_idx_list):
    # Procesa los índices de RMS
    if len(rms_idx_list) > 0:
        for idx_rms in rms_idx_list:
            events.rms_descargada_event.clear()
            byte_array = idx_rms.to_bytes(2, byteorder='little', signed=True)
            command_db = COMMAND_DB + byte_array

            # Marca cada medición RMS como descargada
            await write_characteristic(client, WRITE_CHAR_UUID, command_db)
            logging.info(
                f"----- ✅ Marcando medición RMS {idx_rms} como descargada")
            await asyncio.sleep(0.2)
            try:
                # await asyncio.wait_for(events.rms_descargada_event.wait(), timeout=TIME_TO_MARK_DOWNLOAD)
                await wait_event(events.rms_descargada_event, TIME_TO_MARK_DOWNLOAD)
            except asyncio.TimeoutError:
                logging.error(
                    f"***** ⚠️ Function:process_device | TimeOut Marcando medición RMS {idx_rms} como descargada")
                events.rms_descargada_event.set()
            except Exception as e:
                logging.error(
                    f"***** 🚨 Error inesperado Marcando medición RMS {idx_rms}: {e}")
                events.rms_descargada_event.set()  # Establece el evento en caso de error


        # Guarda el estado de RMS en memoria
        await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_SAVE_RMS_MEM)
        logging.info(f"----- 📌 Guardando el estado de RMS en memoria")

        try:
            # await asyncio.wait_for(events.rms_mem_save_event.wait(), timeout=TIME_TO_SAVE_MEM)
            await wait_event(events.rms_mem_save_event, TIME_TO_SAVE_MEM)
        except asyncio.TimeoutError:
            logging.error(
                f"***** ⚠️ Function:process_device | TimeOut guardando RMS status en memoria")
            events.rms_mem_save_event.set()
        except Exception as e:
            logging.error(
                f" 🚨 Error inesperado guardando RMS status en memoria: {e}")
            events.rms_mem_save_event.set()  # Establece el evento en caso de error


async def download_measurements(client):
    events.measurements_processed_event.clear()
    # await client.write_gatt_char(WRITE_CHAR_UUID, COMMAND_MED)
    await write_characteristic(client, WRITE_CHAR_UUID, COMMAND_MED)
    logging.info("----- 🧾 Solicitando mediciones guardadas")
    try:
        # await asyncio.wait_for(events.measurements_processed_event.wait(), timeout=TIMEOUT_DEVICE_PROCESS)
        await wait_event(events.measurements_processed_event, TIMEOUT_DEVICE_PROCESS)
    except asyncio.TimeoutError:
        logging.error("***** ⚠️ Timeout Solicitando mediciones guardadas.")
        events.measurements_processed_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(
            f"***** 🚨 Error inesperado Solicitando mediciones guardadas: {e}")
        # Establece el evento en caso de error
        events.measurements_processed_event.set()


async def process_commands(client, device_address):
    global hayComandos, command_id_actual, cookies
    WIDNODE_CMD = []
    url = f"{API_URL}/command/widnode/{device_address}"
    async with httpx.AsyncClient(cookies=cookies) as clientWeb:
        response = await clientWeb.get(url)

        if response.status_code == 200:
            data = response.json()
            # Convierte la respuesta en una lista de listas
            WIDNODE_CMD = [[item['command_id'], item['widnode_id'],
                            item['command'], item['date'], item['ejecutado']] for item in data]
        else:
            logging.error(
                f"🚨 Failed to fetch commands for device {device_address}: {response.status_code}")

    # logging.info(f"WIDNODE ID COMMAND: {WIDNODE_CMD}")

    for command in WIDNODE_CMD:
        # print(f"commando por ejecutar {command}")
        command_id, widnode_id, command_text, date, ejecutado = command

        # print(f"command_text por ejecutar {command_text}")
        logging.info(f"----- 🧾 Enviando comando agendado id: {command_id}")
        command_id_actual = command_id

        # if command_text == 'SURd':
        hayComandos = True
        events.cmd_processed_event.clear()
        # print(base64.b64decode(command_text))
        # await client.write_gatt_char(WRITE_CHAR_UUID, base64.b64decode(command_text))
        await write_characteristic(client, WRITE_CHAR_UUID, base64.b64decode(command_text))
        try:
            # await asyncio.wait_for(events.cmd_processed_event.wait(), timeout=TIMEOUT_DEVICE_PROCESS)
            await wait_event(events.cmd_processed_event, TIMEOUT_DEVICE_PROCESS)
        except asyncio.TimeoutError:
            logging.error("***** ⚠️ Timeout Enviando comando agendado.")
            events.cmd_processed_event.set()  # Asegúrate de liberar el evento
        except Exception as e:
            logging.error(f"🚨 Error inesperado Enviando comando agendado: {e}")
            events.cmd_processed_event.set()  # Establece el evento en caso de error

        hayComandos = False

async def should_restart_adapter() -> bool:
    """
    Devuelve True si el adaptador parece no saludable:
    - bluetoothctl Powered != yes
    - 2 escaneos cortos consecutivos (3s) sin ver ni un solo anuncio
    """
    try:
        from utils import is_bluetooth_powered
        if not is_bluetooth_powered(logging):
            logging.warning("⚠️ Adapter no está Powered en bluetoothctl show.")
            return True
    except Exception as e:
        logging.debug(f"No se pudo verificar Powered: {e}")

    try:
        r1 = await BleakScanner.discover(timeout=3.0)
        if len(r1) > 0:
            return False
        r2 = await BleakScanner.discover(timeout=3.0)
        if len(r2) > 0:
            return False
        logging.warning("⚠️ Escaneo vacío (2x3s); se sugiere reiniciar hci0.")
        return True
    except Exception as e:
        logging.debug(f"Error en discover para health-check: {e}")
        # si ni siquiera podemos escanear, reiniciar
        return True


# HANDLER BLE NOTIFICATIONS
def notification_handler(sender, data, client):
    global buffer, msg_count,rms_download_active,cantidad_byte_med_ext,node_busy
    address = data[:6]
    # logging.info(data)
    command_type = data[6]
    if command_type == 0xCA:    # SOLICITA LA CONFIGURACION
        asyncio.create_task(process_ca_response(data, client))
    elif command_type == 0x29:    # SOLICITA ERROR STATUS
        asyncio.create_task(process_29_response(data, client))
    elif command_type == 0x25:    # SOLICITA ALARM STATE
        asyncio.create_task(process_25_response(data, client))
    elif command_type == 0xDE:   # MENSAJE CON CANTIDAD DE MENSAJES QUE SE VAN A RECIBIR
        process_de_response(data, client)
    elif command_type == 0xDD:   # RECEPCION DE MEDICION RMS
        if rms_download_active:
            asyncio.create_task(process_dd_response_locked(data, client))
    elif command_type == 0xCC:  # RECEPCION DE HEADER MEDICIONES
        asyncio.create_task(process_cc_response(data, client))
    elif command_type == 0xDB:   # RMS marcado como descargado
        events.rms_descargada_event.set()
    elif command_type == 0xCF:   # MED marcado como descargado
        events.med_descargada_event.set()
    elif command_type == 0x52:
        events.rms_mem_save_event.set()
    elif command_type == 0x60:  # download medicion extendida
        asyncio.create_task(process_60_response_locked(data, client))

async def process_60_response_locked(data, client):
    async with globals()["measurement_ext_lock"]:
        await process_60_response(data, client)
async def process_dd_response_locked(data, client):
    async with globals()["rms_lock"]:
        await process_dd_response(data, client)

def parse_diagnostico_ble(msg: str) -> dict:
    errores = {}
    try:
        for parte in msg.split(','):
            if ':' in parte:
                clave, valor = parte.split(':')
                errores[clave] = int(valor)
    except Exception as e:
        logging.error(f"Error al parsear diagnóstico: {e}")
    return errores
# TRATAMIENTOD DE RESPUESTA DE ERROR STATUS
async def process_29_response(data, client):
    global cookies
    mensaje_bytes = data[7:]  # Saltás los primeros 7 bytes (ID, encabezado, etc.)
    mensaje = mensaje_bytes.decode('utf-8').strip()
    errores = parse_diagnostico_ble(mensaje)  # Esto devuelve un dict
    widnode_id = client.address
    urlErrorStatus = f"{API_URL}/widnodes/error_status/{widnode_id}"
    logging.info(f"----- 🧾 Enviando error status | mensaje: {errores}")
    try:
        async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientconfig:
            response = await clientconfig.put(urlErrorStatus, json=errores)
            # Manejar la respuesta
            # if response.status_code == 201 or response.status_code == 200:
            #     logging.info(f"----- ✅ wIdnode error status actualizada")
            if response.status_code == 400:
                logging.error(f"***** 🚨 Error Widnode update Bad Request: {response.json()}")
            elif response.status_code == 404:
                logging.error(f"***** 🚨 Error Widnode not found.")
            elif response.status_code != 200 and response.status_code !=201:
                logging.error(f"***** 🚨 Error actualizando error status {response.status_code}: {response.json()}")
    except Exception as e:
        print("An error occurred:", str(e))

    events.error_status_processed_event.set()
    
# TRATAMIENTO DE RESPUESTA DE CONFIGURACION RECIBIDA
async def process_ca_response(data, client):
    global cookies
    sample_rate = data[8]
    time_to_mon = int.from_bytes(data[9:11], byteorder='little')
    time_to_med = int.from_bytes(data[11:13], byteorder='little')
    state = data[13]
    alarm_x = struct.unpack('<f', data[14:18])[0]
    alarm_y = struct.unpack('<f', data[18:22])[0]
    alarm_z = struct.unpack('<f', data[22:26])[0]
    alarm_temp = struct.unpack('<f', data[26:30])[0]
    alarm_x_vel = struct.unpack('<f', data[30:34])[0]
    alarm_y_vel = struct.unpack('<f', data[34:38])[0]
    alarm_z_vel = struct.unpack('<f', data[38:42])[0]
    alarm_mode = data[42]
    filtro = data[43]
    if len(data) > 48:
        battlevel = struct.unpack('<f', data[44:48])[0]
    else:
        battlevel = 0

    # logging.info(f"RSSI: {rssi_device_connected}")

    # Convertir las listas de Python a arrays de PostgreSQL
    widnode_id = client.address

    # logging.info(f"----- ✅  Actualizando configuracion widnode:{widnode_id}")
    # logging.info(f"----- sample: {sample_rate} | time_to_mon:{time_to_mon} | time_to_med: {time_to_med} | state:{state} | alarm_x:{alarm_x } | alarm_y:{alarm_z } | alarm_x:{alarm_z } | alarm_temp:{alarm_temp } | alarm_x_vel:{alarm_x_vel} | alarm_y_vel: {alarm_y_vel} | alarm_z_vel: {alarm_z_vel}")

    # print(f"widnode ID: {client.address}")
    try:
        # Insertar los datos en la tabla measurements
        data = {
            "sample_rate": sample_rate,
            "time_to_mon": time_to_mon,
            "time_to_med": time_to_med,
            "alarm_x": alarm_x,
            "alarm_y": alarm_y,
            "alarm_z": alarm_z,
            "alarm_temp": alarm_temp,
            "state": state,
            "alarm_x_vel": alarm_x_vel,
            "alarm_y_vel": alarm_y_vel,
            "alarm_z_vel": alarm_z_vel,
            "rssi": rssi_device_connected,
            "alarm_mode": alarm_mode,
            "battlevel": battlevel,
        }

        urlconfig = f"{API_URL}/widnodes/{widnode_id}?update_type=complementary"

        async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientconfig:
            response = await clientconfig.put(urlconfig, json=data)
            # Manejar la respuesta
            # if response.status_code == 200:
                # logging.info(f"----- ✅ wIdnode configuracion actualizada")
            if response.status_code == 400:
                logging.error(f"***** 🚨 Error Widnode update Bad Request: {response.json()}")
            elif response.status_code == 404:
                logging.error(f"***** 🚨 Error Widnode not found.")
            elif response.status_code != 200:
                logging.error(f"***** 🚨 Error actualizando configuracion {response.status_code}: {response.json()}")

    except Exception as e:
        print("An error occurred:", str(e))

    events.config_processed_event.set()

def clean_json_floats(obj):
    """Convierte NaN o infinitos en None para compatibilidad JSON"""
    return {
        k: (None if isinstance(v, float) and (
            math.isnan(v) or math.isinf(v)) else v)
        for k, v in obj.items()
    }

# TRATAMIENTO DE RESPUESTA DE ALARMA STATE
async def process_25_response(data, client):
    global cookies
    try:
        alarm_rms = data[7]
        alarm_vel = data[8]
        alarm_year = data[9]
        alarm_month = data[10]
        alarm_day = data[11]
        alarm_hour = data[12]
        alarm_minute = data[13]
        alarm_second = data[14]
        # logging.info(f'tamaño buffer alarma {len(data)}')
        
        if len(data)>16: 
            alarm_med_x=struct.unpack('<f', data[15:19])[0]
            alarm_med_y=struct.unpack('<f', data[19:23])[0]
            alarm_med_z=struct.unpack('<f', data[23:27])[0]
            alarm_med_temp=struct.unpack('<f', data[27:31])[0]
            alarm_med_x_vel=struct.unpack('<f', data[31:35])[0]
            alarm_med_y_vel=struct.unpack('<f', data[35:39])[0]
            alarm_med_z_vel=struct.unpack('<f', data[39:43])[0]
        else:
            alarm_med_x = 0
            alarm_med_y = 0
            alarm_med_z = 0
            alarm_med_temp = 0
            alarm_med_x_vel = 0
            alarm_med_y_vel = 0
            alarm_med_z_vel = 0
        
        fecha_alarm = datetime.datetime(alarm_year+2000, alarm_month, alarm_day, alarm_hour, alarm_minute, alarm_second)
        widnode_id = client.address
        # logging.info(f"----- ✅  Actualizando alarmas widnode:{widnode_id}")
        data_alarm = {
            "alarm_rms": alarm_rms,
            "alarm_vel": alarm_vel,
            "fecha": fecha_alarm.strftime('%Y-%m-%d %H:%M:%S'),
            "med_x": alarm_med_x,
            "med_y": alarm_med_y,
            "med_z": alarm_med_z,
            "med_temp": alarm_med_temp,
            "med_x_vel": alarm_med_x_vel,
            "med_y_vel": alarm_med_y_vel,
            "med_z_vel": alarm_med_z_vel
        }

        # logging.info(data_alarm)
        urlalarm = f"{API_URL}/alarm/{widnode_id}"
        # logging.info(urlalarm)
        if (alarm_rms == 0 and alarm_vel == 0):
            events.alarm_processed_event.set()
            return
        try:
            async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientconfig:
                response = await clientconfig.post(urlalarm, json=data_alarm)
                # Manejar la respuesta
                # if response.status_code == 201 or response.status_code == 200:
                #     logging.info(f"----- ✅ wIdnode alarm actualizada")
                if response.status_code == 400:
                    logging.error(f"***** 🚨 Error Widnode update Bad Request: {response.json()}")
                elif response.status_code == 404:
                    logging.error(f"***** 🚨 Error Widnode not found.")
                elif response.status_code == 409:
                    logging.error(f"***** ⚠️ Alarma ya registrada .")
                elif response.status_code != 200 and response.status_code !=201:
                    logging.error(f"***** 🚨 Error actualizando alarma {response.status_code}: {response.json()}")
        except Exception as e:
            print("An error occurred:", str(e))

    except ValueError:
        logging.error(f'***** 🚨 📅 Function:process_25_response |  Formato de fecha inccorecto widnode: {client.address} ')
        logging.error(f"***** 🔢 Data: {binascii.hexlify(data).decode('utf-8')}")
        
    events.alarm_processed_event.set()

# TRATAMIENTO DE RESPUESTA DE CANTIDAD DE MENSAJES A RECIBIR -RMS
def process_de_response(data, client):
    global cantidadMensajesRMS, rms_idx_list
    rms_idx_list = []
    cantidadMensajesRMS = int.from_bytes(data[7:9], byteorder='little')
    # print(f'cantidad de mensajes a recibir {cantidadMensajes}')
    if cantidadMensajesRMS > 0:
        events.rms_processed_event.clear()
    else:
        rms_idx_list = []
        events.rms_processed_event.set()
# TRATAMIENTO DE RESPUESTA DE RMS RECIBIDA
async def process_dd_response(data, client):
    global cantidadMensajesRMS, cookies,widnode_modbus_index,modbus_pub
    
    index_rms = int.from_bytes(data[7:9], byteorder='little')
    index_rms2 = int.from_bytes(data[9:11], byteorder='little')
    # index_rms = int.from_bytes(data[3:5], byteorder='little')

    # print(f"index_rms 1: {index_rms} | index_rms 2: {index_rms2}")

    widnode_id = client.address
    year = data[11]
    month = data[12]
    day = data[13]
    hour = data[14]
    minute = data[15]
    second = data[16]

    if second > 59:
        second = 59

    rmsx = struct.unpack('<f', data[17:21])[0]
    rmsy = struct.unpack('<f', data[21:25])[0]
    rmsz = struct.unpack('<f', data[25:29])[0]
    temp = struct.unpack('<f', data[29:33])[0]
    rmsx_vel = struct.unpack('<f', data[33:37])[0]
    rmsy_vel = struct.unpack('<f', data[37:41])[0]
    rmsz_vel = struct.unpack('<f', data[41:45])[0]

    sample_rate = data[45]
    alarma = data[46]
    alarma_vel = data[47]

    mX = 0
    rX = 0
    skX = 0
    kuX = 0
    pX = 0
    cfX = 0
    sfX = 0
    imfX = 0

    mY = 0
    rY = 0
    skY = 0
    kuY = 0
    pY = 0
    cfY = 0
    sfY = 0
    imfY = 0

    mZ = 0
    rZ = 0
    skZ = 0
    kuZ = 0
    pZ = 0
    cfZ = 0
    sfZ = 0
    imfZ = 0

    if len(data) >= 144:
        mX = struct.unpack('<f', data[48:52])[0]
        rX = struct.unpack('<f', data[52:56])[0]
        skX = struct.unpack('<f', data[56:60])[0]
        kuX = struct.unpack('<f', data[60:64])[0]
        pX = struct.unpack('<f', data[64:68])[0]
        cfX = struct.unpack('<f', data[68:72])[0]
        sfX = struct.unpack('<f', data[72:76])[0]
        imfX = struct.unpack('<f', data[76:80])[0]

        mY = struct.unpack('<f', data[80:84])[0]
        rY = struct.unpack('<f', data[84:88])[0]
        skY = struct.unpack('<f', data[88:92])[0]
        kuY = struct.unpack('<f', data[92:96])[0]
        pY = struct.unpack('<f', data[96:100])[0]
        cfY = struct.unpack('<f', data[100:104])[0]
        sfY = struct.unpack('<f', data[104:108])[0]
        imfY = struct.unpack('<f', data[108:112])[0]

        mZ = struct.unpack('<f', data[112:116])[0]
        rZ = struct.unpack('<f', data[116:120])[0]
        skZ = struct.unpack('<f', data[120:124])[0]
        kuZ = struct.unpack('<f', data[124:128])[0]
        pZ = struct.unpack('<f', data[128:132])[0]
        cfZ = struct.unpack('<f', data[132:136])[0]
        sfZ = struct.unpack('<f', data[136:140])[0]
        imfZ = struct.unpack('<f', data[140:144])[0]

        try:
            fecha = datetime.datetime(
                year + 2000, month, day, hour, minute, second)
        except Exception as e:
            logging.error(f'🚨 Error al construir la fecha: {e}')
            logging.error(
                f"year = {year} | month = {month} | day = {day} | hour = {hour} | minute = {minute} | second = {second}")
            logging.error(
                f"***** 🔢 Data: {binascii.hexlify(data).decode('utf-8')}")
            cantidadMensajesRMS -= 1
            return  # Salir de la función

        data_monitoring = {
            "widnode_id": widnode_id,
            "fecha": fecha.strftime('%Y-%m-%d %H:%M:%S'),
            "rms_x": rmsx,
            "rms_y": rmsy,
            "rms_z": rmsz,
            "temp": temp,
            "sample_rate": sample_rate,
            "alarma": alarma,
            "rms_x_vel": rmsx_vel,
            "rms_y_vel": rmsy_vel,
            "rms_z_vel": rmsz_vel,
            "alarma_vel": alarma_vel,
            "media_x": mX,
            "rms_axis_x": rX,
            "skew_x": skX,
            "kurtosis_x": kuX,
            "ptp_x": pX,
            "crest_factor_x": cfX,
            "shape_factor_x": sfX,
            "impulse_factor_x": imfX,
            "media_y": mY,
            "rms_axis_y": rY,
            "skew_y": skY,
            "kurtosis_y": kuY,
            "ptp_y": pY,
            "crest_factor_y": cfY,
            "shape_factor_y": sfY,
            "impulse_factor_y": imfY,
            "media_z": mZ,
            "rms_axis_z": rZ,
            "skew_z": skZ,
            "kurtosis_z": kuZ,
            "ptp_z": pZ,
            "crest_factor_z": cfZ,
            "shape_factor_z": sfZ,
            "impulse_factor_z": imfZ,
        }
        data_monitoring = clean_json_floats(data_monitoring)
        # print(data)
        urlmonitoring = f"{API_URL}/monitoring/"
        try:
            async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientMon:
                response = await clientMon.post(urlmonitoring, json=data_monitoring)
                if response.status_code == 201:
                    rms_idx_list.append(index_rms2)
                    logging.info(
                        f"----- ✅ Medicion de RMS insertada indice: {index_rms2} fecha: {fecha}")
                else:
                    logging.error(
                        f"🚨 Error inserting monitoring data: {response.status_code} - {response.text}")
        except httpx.ConnectTimeout:
            logging.error(
                "Connection timed out. The server may be down or unreachable.")
        except httpx.RequestError as e:
            logging.error(
                f"🚨 Error de red en la petición a {e.request.url!r}: {e}")
        except Exception as e:
            logging.error(
                f"🚨 Error inesperado al insertar RMS: {type(e).__name__}: {e}")
            logging.error(
                f"Payload: {json.dumps(data_monitoring, default=str)}")


    # --- Publicación a Modbus (si config habilitada y hay idx) ---
    if modbus_srv is not None:
        widnode_id = client.address
        idx = widnode_modbus_index.get(widnode_id, 0)
        if idx > 0:
            # normaliza year si te llega en dos dígitos
            y = year if year >= 2000 else (2000 + year)
            # proteger segundo=60
            ts_in = int(datetime.datetime(y, month, day, hour, minute, min(second, 59)).timestamp())

            vals = {
                "rmsx": rmsx, "rmsy": rmsy, "rmsz": rmsz,
                "temp": temp,
                "rmsx_vel": rmsx_vel, "rmsy_vel": rmsy_vel, "rmsz_vel": rmsz_vel,
            }
            try:
                updated = await modbus_srv.update_block(idx, ts_in, vals)
                if updated:
                    logging.info(f"[MODBUS_SERVER] actualizado idx={idx} ({widnode_id})")
                else:
                    logging.info(f"[MODBUS_SERVER] omitido idx={idx} (timestamp no más nuevo)")
            except Exception as e:
                logging.error(f"[MODBUS_SERVER] error al actualizar idx={idx}: {e}")
    # --- fin publicación Modbus ---

    cantidadMensajesRMS -= 1
    if cantidadMensajesRMS <= 0:
        events.rms_processed_event.set()

# RECIBE EL ARRAY DE ESTADO DE MEDICIONES
async def process_cc_response(data, client):
    uint16_value = int.from_bytes(data[7:9], byteorder='little')
    array_50 = data[9:209]
    # logging.info(array_50)
    events.med_array_event.clear()
    # print(f"Recibido CC. Uint16: {uint16_value}, Array: {array_50}")
    await send_commands_ce(array_50, client)
    try:
        # await asyncio.wait_for(events.med_array_event.wait(), timeout=TIMEOUT_DEVICE_PROCESS)
        await wait_event(events.med_array_event, TIMEOUT_DEVICE_PROCESS)
    except asyncio.TimeoutError:
        logging.error("*****⚠️ Timeout Solicitando estado de Mediciones")
        events.med_array_event.set()  # Asegúrate de liberar el evento
    except Exception as e:
        logging.error(f"🚨 Error inesperado Solicitando estado de Mediciones: {e}")
        events.med_array_event.set()  # Establece el evento en caso de error

def reset_measurement_state():
    global fecha_extendida, cantidad_byte_med_ext, medicion_descargada, sample_rate
    global temp, alarma, alarma_vel, error_en_fecha
    fecha_extendida = None
    cantidad_byte_med_ext = 0
    medicion_descargada = False
    sample_rate = 0
    temp = None
    alarma = 0
    alarma_vel = 0
    error_en_fecha = False

# PROCESA EL ARRAY DE ESTADO DE MEDICIONES Y ENVIA LOS COMANDOS PARA DESCARGARLAS
async def send_commands_ce(array_50, client):
    global msg_count, idx_actual, medicion_descargada, error_en_fecha,node_busy,MAX_WAIT_TIME_BUSY
    try:
        for idx, value in enumerate(array_50):

            if value == 1:
                msg_count = 0
                events.msg_received_event.clear()
                command_ce = COMMAND_CE + bytearray([idx + 2])
                # logging.info(f"comando enviado {command_ce}")
                reset_measurement_state()

                idx_actual = idx + 2

                try:
                    # await client.write_gatt_char(WRITE_CHAR_UUID, command_ce)
                    await write_characteristic(client, WRITE_CHAR_UUID, command_ce)
                    logging.info(
                        f"----- 🧾 Solicitud de descarga de medicion índice {idx + 2}")
                except BleakError as e:
                    logging.error(
                        f"***** 🚨 Error al solicitar medicion índice {idx + 2}: {e}")

                try:
                    # await asyncio.wait_for(events.msg_received_event.wait(), timeout=TIMEOUT)
                    await wait_event(events.msg_received_event, TIMEOUT)
                    # logging.info(f"----- 🧾 SALIENDO DEL WAIT  msg_received_event índice {idx + 2}")
                    
                    if medicion_descargada:

                        events.med_descargada_event.clear()
                        command_cf = COMMAND_CF + bytearray([idx_actual])
                        await write_characteristic(client, WRITE_CHAR_UUID, command_cf)
                        logging.info(f"----- ✅ Marcando medicion {idx_actual} como descargada")
                        try:
                            # await asyncio.wait_for(events.med_descargada_event.wait(), timeout=TIME_TO_MARK_DOWNLOAD)
                            await wait_event(events.med_descargada_event, TIME_TO_MARK_DOWNLOAD)
                        except asyncio.TimeoutError:
                            logging.error(
                                f"***** ⚠️ TimeOut Marcando medicion {idx_actual} como descargada")
                            events.med_descargada_event.set()
                        except Exception as e:
                            logging.error(
                                f"***** 🚨 Error inesperado Marcando medicion {idx_actual} como descargada: {e}")
                            events.med_descargada_event.set()  # Establece el evento en caso de error
                    else:
                        logging.error(f"***** 🚨 Function:send_commands_ce | Error al intentar descargar la medicion indice {idx_actual} ")

                except asyncio.TimeoutError:
                    logging.error(f"***** 🚨 Function:send_commands_ce | events.msg_received_event timeout problema en la recepcion de la medicion indice {idx_actual}")
                    try:
                        if client.is_connected:
                            # refrescar servicios/notify por si quedaron colgados
                            try:
                                await client.get_services()
                            except Exception:
                                pass
                            try:
                                await client.start_notify(NOTIFY_CHAR_UUID, lambda s,d: notification_handler(s,d, client))
                            except Exception:
                                pass
                        else:
                            logging.warning("🔌 Cliente no conectado tras timeout; el caller debería reconectar.")
                    except Exception as e:
                        logging.debug(f"refresh post-timeout: {e}")
                    events.med_descargada_event.clear()
                    if error_en_fecha:
                        command_cf = COMMAND_CF + bytearray([idx_actual])
                        await write_characteristic(client, WRITE_CHAR_UUID, command_cf)
                        logging.info(f"----- 🚨 Error: Marcando medicion {idx_actual} como descargada por error en fecha ")

                        # try:
                        #     await asyncio.wait_for(events.med_descargada_event.wait(), timeout=TIME_TO_MARK_DOWNLOAD)
                        # except asyncio.TimeoutError:
                        #     logging.error(
                        #         f"***** ⚠️ TimeOut Marcando medicion {idx_actual} como descargada")
                        #     events.med_descargada_event.set()
                        # except Exception as e:
                        #     logging.error(
                        #         f"***** 🚨 Error inesperado Marcando medicion {idx_actual} como descargada: {e}")
                        #     events.med_descargada_event.set()  # Establece el evento en caso de error

                        events.msg_received_event.set()

                except Exception as e:
                    logging.error(f"***** 🚨 Error inesperado Function:send_commands_ce: {e}")
                    events.msg_received_event.set()  # Establece el evento en caso de error
                await asyncio.sleep(2)

    finally:
        # Asegurar que los eventos se establecen al final, independientemente de los errores
        events.med_array_event.set()
        events.measurements_processed_event.set()

# RECIBE Y PROCESA ENCABEZADO DE MEDICION
async def process_60_response(data, client):
    global fecha_extendida, cantidad_byte_med_ext, medicion_descargada, sample_rate, temp, alarma, alarma_vel, error_en_fecha,node_busy
    # logging.error(f"***** Data 60: {binascii.hexlify(data).decode('utf-8')}")
    result = True

    VALORES_PERMITIDOS = {
                        48017,
                        96017,
                        160019,
                        240017,
                        320021,
                        400019,
                        480023,
                        640025,
                        800027,
                        960029,
                        1120031,
                        1280033,
                        2560049,
                }


    msg_number = int.from_bytes(data[7:11], byteorder='little')

    if msg_number == 0:

        error_en_fecha = False
        # logging.info(f"📥 Recibiendo encabezado: {binascii.hexlify(data).decode('utf-8')}")
        year, month, day, hour, minute, second = data[11:17]
        if (
            year > 99 or
            month < 1 or month > 12 or
            day < 1 or day > 31 or
            hour < 0 or hour > 23 or
            minute < 0 or minute > 59 or
            second < 0 or second > 59
        ):
            logging.warning(
                f"❌ Fecha/hora inválida: Y:{year} M:{month} D:{day} {hour:02}:{minute:02}:{second:02}"
            )    
        try:
            
            fecha_extendida = datetime.datetime(
                year + 2000, month, day, hour, minute, second)
            cantidad_byte_med_ext = struct.unpack('<I', data[17:21])[0]
            sample_rate = data[21]
            temp = struct.unpack('<f', data[22:26])[0]
            alarma = data[26]
            alarma_vel = data[27]
            # logging.info(f"📅 Fecha decodificada: {fecha_extendida}")
            logging.info(f"----- 🔢 Cantidad de bytes esperados: {cantidad_byte_med_ext}")

            # 📌 Validar que `cantidad_byte_med_ext` sea uno de los valores permitidos
            if cantidad_byte_med_ext not in VALORES_PERMITIDOS:
                logging.error(f"🚨 Error: cantidad_byte_med_ext {cantidad_byte_med_ext} no válido. Saltando procesamiento.")
                error_en_fecha = True
                return  # 🔴 Salir sin procesar más
        except ValueError as ve:
            logging.error(f"***** 🚨 Function:process_60_response |  Error en la creación de la fecha: {ve}")
            logging.error(f"***** 🔢 Data: {binascii.hexlify(data).decode('utf-8')}")
            error_en_fecha = True
        except TypeError as te:
            logging.error(f"***** 🚨 Function:process_60_response |  Error de tipo en la creación de la fecha: {te}")
            logging.error(f"***** 🔢 Data: {binascii.hexlify(data).decode('utf-8')}")
            error_en_fecha = True
        except Exception as e:
            logging.error(f"🚨 Error inesperado: {e}")
            error_en_fecha = True

    else:
        index = (msg_number-1) * PACKET_PAYLOAD
        # logging.info(f"indice reccibido: {index} msg_number: {msg_number} Cantidad de bytes esperados: {cantidad_byte_med_ext}")
        buffer_ext[index:index+PACKET_PAYLOAD] = data[11:249]
        # logging.info(f"medicion ext idx: {msg_number}")
        # if msg_number == 2142:
        total_bytes = cantidad_byte_med_ext
        expected_packets = math.ceil((total_bytes - HEADER_SIZE) / PACKET_PAYLOAD)

        # if msg_number >= ((cantidad_byte_med_ext - HEADER_SIZE + PACKET_PAYLOAD-1) / PACKET_PAYLOAD)-1:
        if msg_number >= expected_packets:

            if fecha_extendida is None:
                logging.error("🚨 fecha_extendida no fue inicializada correctamente.")
                events.msg_received_event.set()
                events.measurementsEX_processed_event.set()
                return
            
            logging.info(f"----- ✅ Medicion EXT recibia completa nodo: {client.address} fecha: {fecha_extendida}")
            
            raw_data = buffer_ext[: total_bytes - HEADER_SIZE]
            # resultado = descomponer_medicion_ext(buffer_ext[:total_bytes-HEADER_SIZE])
            resultado = descomponer_medicion_ext(raw_data)

            cantidad_byte_med_ext = 0
            # Convertir las listas de Python a arrays de PostgreSQL
            widnode_id = client.address
            if resultado is None:
                logging.error(
                    "🚨 descomponer_medicion_ext returned None. Skipping measurement insertion.")
                medicion_descargada = False
                events.msg_received_event.set()
                events.measurementsEX_processed_event.set()
                return

            data = {
                "widnode_id": widnode_id,
                "serie_x": resultado["serieX"],
                "serie_y": resultado["serieY"],
                "serie_z": resultado["serieZ"],
                "fecha": fecha_extendida.strftime('%Y-%m-%d %H:%M:%S'),
                "rms_x": resultado["rmsX"],
                "rms_y": resultado["rmsY"],
                "rms_z": resultado["rmsZ"],
                "rms_x_vel": resultado["rmsX_vel"],
                "rms_y_vel": resultado["rmsY_vel"],
                "rms_z_vel": resultado["rmsZ_vel"],
                "sample_rate": sample_rate,
                "temp": temp,
                "alarma": alarma,
                "alarma_vel": alarma_vel,
                # === Globales tiempo, igual que el paquete RMS ===
                "media_x": resultado["mediaX"],
                "rms_axis_x": resultado["rmsAxisX"],
                "skew_x": resultado["skewX"],
                "kurtosis_x": resultado["kurtosisX"],
                "ptp_x": resultado["ptpX"],
                "crest_factor_x": resultado["crestFactorX"],
                "shape_factor_x": resultado["shapeFactorX"],
                "impulse_factor_x": resultado["impulseFactorX"],

                "media_y": resultado["mediaY"],
                "rms_axis_y": resultado["rmsAxisY"],
                "skew_y": resultado["skewY"],
                "kurtosis_y": resultado["kurtosisY"],
                "ptp_y": resultado["ptpY"],
                "crest_factor_y": resultado["crestFactorY"],
                "shape_factor_y": resultado["shapeFactorY"],
                "impulse_factor_y": resultado["impulseFactorY"],

                "media_z": resultado["mediaZ"],
                "rms_axis_z": resultado["rmsAxisZ"],
                "skew_z": resultado["skewZ"],
                "kurtosis_z": resultado["kurtosisZ"],
                "ptp_z": resultado["ptpZ"],
                "crest_factor_z": resultado["crestFactorZ"],
                "shape_factor_z": resultado["shapeFactorZ"],
                "impulse_factor_z": resultado["impulseFactorZ"],
            }
            # logging.info(f" rmsy: {data.rms_y}")
            # print(data)
            # logging.info(f"RMS FFT X: {rmsx}, Y: {rmsy}, Z: {rmsz}")
            # logging.info(f"RMS FFT vel X: {rmsx_vel}, Y: {rmsy_vel}, Z: {rmsz_vel}")
            # logging.info(f"fecha : {fecha_extendida.strftime('%Y-%m-%d %H:%M:%S')}")
            # logging.info(f"alarma: {alarma} alarma_vel: {alarma_vel}")

            urlmeasurement = f"{API_URL}/measurement_ext/"
            try:
                # logging.info("📡 Insertando medición extendida en el backend...")
                # logging.debug(f"📦 Payload: {data}")
                # logging.debug(f"🌐 URL destino: {urlmeasurement}")
                # ——— observabilidad extra ———
                cid = uuid.uuid4().hex[:8]  # correlation id corto
                pts_x = len(data.get("serie_x", []))
                pts_y = len(data.get("serie_y", []))
                pts_z = len(data.get("serie_z", []))
                approx_bytes = 4 * (pts_x + pts_y + pts_z)  # float32*3
                logging.info(f"📡[{cid}] Insertando medición ext: "
                             f"pts=({pts_x},{pts_y},{pts_z}) ~{approx_bytes/1024:.1f} KiB → {urlmeasurement}")

                timeout = httpx.Timeout(connect=10.0, read=120.0, write=120.0, pool=60.0)
                limits = httpx.Limits(max_keepalive_connections=10, max_connections=20)

                t0 = time.perf_counter()
                
                # async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientMeaExt:
                # async with httpx.AsyncClient(cookies=cookies, timeout=timeout, limits=limits) as clientMeaExt:
                async with httpx.AsyncClient(cookies=cookies, timeout=timeout, limits=limits, http2=True) as clientMeaExt:
                    # response = await clientMeaExt.post(urlmeasurement, json=data)
                    # resp = await clientMeaExt.post(
                    #     urlmeasurement,
                    #     json=data,
                    #     headers={"X-Request-ID": cid}
                    # )

                    body = json.dumps(data, separators=(",", ":")).encode("utf-8")
                    gz  = gzip.compress(body, compresslevel=5)
                    headers = {
                        "Content-Type": "application/json",
                        "Content-Encoding": "gzip",
                        "X-Request-ID": cid,
                    }
                    resp = await clientMeaExt.post(urlmeasurement, content=gz, headers=headers)
                dt = time.perf_counter() - t0
                ctype = resp.headers.get("content-type")
                clen  = resp.headers.get("content-length")
                logging.info(f"📬[{cid}] HTTP {resp.status_code} en {dt:.2f}s "
                             f"(ctype={ctype}, len={clen})")

                    # logging.info("📬 Respuesta del backend: %s", response.status_code)
                if resp.status_code == 201:
                    # logging.info("✅ Measurement extended inserted successfully via API")
                    logging.info(f"✅[{cid}] Measurement ext registrada")
                    medicion_descargada = True
                else:
                    body_snip = (resp.text or "")[:300].replace("\n", " ")
                    logging.error(f"🚨[{cid}] HTTP {resp.status_code} body='{body_snip}…'")
                    medicion_descargada = False

            except httpx.ConnectTimeout:
                logging.error(f"⏱️ Conexión agotada (connect timeout) al insertar medición ext")
                medicion_descargada = False
            except httpx.ReadTimeout:
                logging.error(f"⏳ Lectura agotada (read timeout) esperando respuesta del backend")
                medicion_descargada = False
            except httpx.ConnectError as e:
                cause = repr(getattr(e, "__cause__", e))
                logging.error(f"🔌 Error de conexión (DNS/firewall/拒否). Causa: {cause}")
                medicion_descargada = False
            except httpx.RequestError as e:
                cause = repr(getattr(e, "__cause__", e))
                logging.error(f"🌐 RequestError: {e!r} | cause={cause}")
                medicion_descargada = False
            except Exception:
                logging.exception("🚨 Error inesperado al insertar medición extendida")
                medicion_descargada = False
            finally:
                # logging.info("📦 Finalizando recepción de medición extendida para índice %s", idx_actual)
                events.msg_received_event.set()
                events.measurementsEX_processed_event.set()

async def process_widnode(device_address):
    global rms_idx_list,indices_para_marcar, command_id_actual, hayComandos, cookies,node_busy,widnode_modbus_index

    # al inicio, una vez por ciclo del nodo:
    modbus_id = await get_modbus_index_for_widnode(device_address)
    if modbus_id <= 0:
        logging.warning(f"Modbus idx faltante para {device_address}; no se publicará a Modbus")
    widnode_modbus_index[device_address] = modbus_id

    # Verifica si hay comandos pendientes por procesar
    logging.info("Ejecutando schedule task (tareas programadas)")
    # Verifica si hay comandos pendientes por procesar con execute_scheduled_tasks
    try:
        # Llama a la nueva función desde app2.py
        await execute_scheduled_tasks(cookies)
        # await ejecutar_tareas_programadas(API_URL,cookies)
        # logging.info("Scheduled tasks executed successfully.")
    except Exception as e:
        logging.error(f"🚨 Error executing scheduled tasks: {e}")

    # inicio de proceso para widnode {device_address}
    # logging.info(f"📌START PROCESS DEVICE: {device_address}...")
    logging.info(f"----- 🔍 Buscando dispositivo {device_address}...")
    device = await find_device_by_address(device_address)

    if device:
        retries = 0
        success = False

        while retries < MAX_RETRIES and not success:
            client = BleakClient(device)
            try:
                await client.connect()
                logging.info(f"----- 🔌 Conectado a {device_address}.")
                # Marcar bonded device como Trusted (opcional, recomendado)
                try:
                    set_cached_rpa(device_address, client.address)
                except Exception:
                    pass
                try:
                    await mark_trusted(device_address)
                except Exception as _:
                    pass


                await detectar_nodo_ocupado(client)

                if node_busy:
                    logging.warning("⏳ Nodo ocupado. Esperando que termine antes de continuar...")
                    retries += 1
                    await asyncio.sleep(2)  # un pequeño delay antes de reintentar
                    continue  # Salta al siguiente intento si el nodo está ocupado

                # Comienza la notificación y configura el dispositivo
                if NOTIFY_CHAR_UUID is None:
                    raise ValueError("NOTIFY_CHAR_UUID environment variable is not set.")
                await client.start_notify(NOTIFY_CHAR_UUID, lambda sender, data: notification_handler(sender, data, client))
                await asyncio.sleep(0.5)  # Espera antes de continuar
                await setTime_device(client)
                await asyncio.sleep(0.5)  # Espera antes de continuar
                await configure_device(client)
                await asyncio.sleep(0.5)  # Espera antes de continuar
                await get_error_status_device(client)
                await asyncio.sleep(0.5)  # Espera antes de continuar
                await update_alarm(client)
                await asyncio.sleep(0.5)  # Espera antes de continuar
                # Procesa las descargas y marca el éxito si se completan



                await download_rms(client)
                await asyncio.sleep(0.5)  # Espera antes de continuar
                
                # just before marking
                indices_para_marcar = rms_idx_list.copy()
                rms_idx_list.clear()  # o reiniciar aquí si querés evitar residuos
                await mark_rms_downloaded(client, indices_para_marcar)
                await asyncio.sleep(0.5)  # Espera antes de continuar

                await download_measurements(client)
                success = True

            except Exception as e:
                retries += 1
                logging.error(
                    f"***** 🚨 Function:process_device | Error procesando {device_address}: {e}")
                # insertar_log(
                #     widnode_id=device_address,
                #     tipo="ERR-DISP-DISCONECT",
                #     descripcion=f"Error: {e} | reintento: {retries}"
                # )

                if retries < MAX_RETRIES:
                    logging.info(
                        f" 🔄 Reintentando conexión a {device_address} ({retries}/{MAX_RETRIES})...")
                    await asyncio.sleep(2)  # Espera antes de reintentar
                else:
                    logging.error(f"🚨 No se pudo procesar el dispositivo {device_address} después de {MAX_RETRIES} intentos")

            finally:
                # Desconecta solo después de todos los intentos o si el proceso fue exitoso
                if client.is_connected:
                    await client.disconnect()
                    logging.info(
                        f"----- Cliente desconectado de {device_address}.")

        if success:
            logging.info(f" ✔️ Proceso completado exitosamente para el dispositivo {device_address}")
        else:
            logging.error(f" 🚨 El proceso para el dispositivo {device_address} falló después de {MAX_RETRIES} intentos")

    else:
        logging.info(f"----- ❌ No se encontró el dispositivo.")

def get_system_timezone_via_timedatectl() -> str:
    """Devuelve la zona horaria del sistema según timedatectl."""
    result = subprocess.run(
        ['timedatectl', 'show', '--property=Timezone', '--value'],
        capture_output=True, text=True, check=True
    )
    return result.stdout.strip()

def get_system_timezone() -> str:
    import os, configparser, pathlib, subprocess

    cfg = configparser.ConfigParser()
    cfg.read(os.environ.get('CONFIG_FILE','/data/config.ini'))
    tz = cfg.get('System', 'timezone', fallback=None)
    if tz:
        return tz

    # Fallbacks (por si alguna vez falta en config.ini)
    # 1) env TZ
    if os.environ.get("TZ"):
        return os.environ["TZ"]
    # 2) timedatectl
    try:
        tz = subprocess.check_output(
            ["timedatectl","show","--property=Timezone","--value"], text=True
        ).strip()
        if tz:
            return tz
    except Exception:
        pass
    # 3) /etc/timezone
    etc_tz = pathlib.Path("/etc/timezone")
    if etc_tz.exists():
        return etc_tz.read_text().strip()
    # 4) symlink /etc/localtime
    try:
        target = pathlib.Path("/etc/localtime").resolve()
        parts = target.parts
        if "zoneinfo" in parts:
            idx = parts.index("zoneinfo") + 1
            return "/".join(parts[idx:])
    except Exception:
        pass

    return "UTC"

# def get_system_timezone() -> str:
#     """
#     Devuelve la zona horaria del sistema de forma robusta:
#     - timedatectl (cuando existe)
#     - /etc/timezone (si existe)
#     - symlink /etc/localtime -> /usr/share/zoneinfo/Region/City
#     - env TZ o 'UTC' como último recurso
#     """
#     import os, pathlib, subprocess, configparser
#     cfg = configparser.ConfigParser()
#     cfg.read(os.environ.get('CONFIG_FILE','/data/config.ini'))
#     tz = cfg.get('System', 'timezone', fallback=None)
#     if tz:
#         return tz
#     # …luego los fallbacks actuales (timedatectl, /etc/timezone, symlink, env TZ, UTC)
#     # 1) timedatectl (cuando hay systemd)
#     try:
#         out = subprocess.run(
#             ['timedatectl', 'show', '--property=Timezone', '--value'],
#             capture_output=True, text=True, check=True
#         )
#         tz = (out.stdout or "").strip()
#         if tz:
#             return tz
#     except Exception:
#         pass

#     # 2) /etc/timezone
#     tz_file = pathlib.Path('/etc/timezone')
#     try:
#         if tz_file.exists():
#             tz = tz_file.read_text(encoding='utf-8').strip()
#             if tz:
#                 return tz
#     except Exception:
#         pass

#     # 3) symlink /etc/localtime
#     try:
#         real = pathlib.Path('/etc/localtime').resolve()
#         prefix = pathlib.Path('/usr/share/zoneinfo')
#         if str(real).startswith(str(prefix)):
#             return str(real.relative_to(prefix))
#     except Exception:
#         pass

#     # 4) env TZ o UTC
#     return os.environ.get('TZ', 'UTC')
# ============================================================
# Desconectar cualquier Device1 conectado en BlueZ (hci0)
# ============================================================
async def disconnect_all_devices():
    """
    Recorre todos los org.bluez.Device1 y llama Disconnect() en los que
    tengan Connected=True. Ignora errores benignos (NotConnected).
    """
    # Usamos el bus del agente si ya está, o abrimos uno temporal
    local_bus = False
    bus = globals().get("BLUEZ_BUS")
    if bus is None:
        from dbus_next.aio import MessageBus
        from dbus_next import BusType
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
        local_bus = True

    try:
        # Obtener todos los objetos administrados por BlueZ
        reply = await _dbus_call(
            bus,
            "org.bluez",
            "/",
            "org.freedesktop.DBus.ObjectManager",
            "GetManagedObjects",
        )
        objects = reply.body[0]  # dict[path] -> dict[iface] -> dict[prop]=Variant

        total = 0
        disconnected = 0
        for path, ifaces in objects.items():
            dev = ifaces.get("org.bluez.Device1")
            if not dev:
                continue
            # Extraer Address y Connected desde Variant
            addr = dev.get("Address").value if "Address" in dev else "unknown"
            connected = dev.get("Connected").value if "Connected" in dev else False
            total += 1
            if connected:
                try:
                    await _dbus_call(bus, "org.bluez", path, "org.bluez.Device1", "Disconnect")
                    logging.info(f"🔌 Desconectado {addr} ({path})")
                    disconnected += 1
                except Exception as e:
                    # Ignorar errores de estado (ya se desconectó, etc.)
                    logging.warning(f"⚠️ No se pudo desconectar {addr}: {e}")

        logging.info(f"🔎 BlueZ tiene {total} devices; desconectados ahora: {disconnected}")
    finally:
        if local_bus:
            try:
                await bus.wait_for_disconnect()  # opcional
            except Exception:
                pass


async def process_devices():
    global cookies  # Usamos las cookies globales

    LOCAL_ADDRESS = getMacBluetooth(logging)
    # logging.info(f" LOCAL ADDRESS = {LOCAL_ADDRESS}")
    ip_addresses = get_ip_addresses()
    timezone = get_system_timezone()
    gw_temp = 0
    with open("/sys/class/thermal/thermal_zone0/temp") as f:
        gw_temp = int(f.read().strip()) / 1000.0

    logging.info(f"🧾 TIMEZONE = {timezone} | IP ADDRESS = {ip_addresses} | | TEMP = {gw_temp}")
    

    # LOCAL_ADDRESS = '98:03:CF:D2:25:EF'
    # logging.info(f"🧾 LOCAL_ADDRESS = {LOCAL_ADDRESS}")
    url = f"{API_URL}/gateway/{LOCAL_ADDRESS}"
    # logging.info(f"🧾 URL = {url}")

    # Leer la versión del firmware desde version.txt
    version_file = "/home/widnode/dev/widnode/version.txt"
    firmware_version = "0.0.0"  # Valor por defecto si falla

    try:
        with open(version_file, "r") as vf:
            firmware_version = vf.read().strip()
    except Exception as e:
        logging.warning(f"⚠️ No se pudo leer el archivo de versión: {e}")

    logging.info(f"Firmware Version = {firmware_version}")

    # Llamada a la API OBTENGO EL ID DEL GATEWAY
    async with httpx.AsyncClient(cookies=cookies) as clientWeb:

        response = await clientWeb.get(url)

        if response.status_code == 200:
            data = response.json()
            WIDNODE_GW = data.get("gw_id")
        else:
            logging.error(f" 🚨 Failed to fetch gw_id for LOCAL_ADDRESS {LOCAL_ADDRESS}: {response.status_code}")
            return

    gateway_ip = f"{API_URL}/gateway/ip/{WIDNODE_GW}"
    gateway_tz = f"{API_URL}/gateway/tz/{WIDNODE_GW}"
    ip_string = " ".join(f"{key}={value}" for key,
                         value in ip_addresses.items())
    
    # logging.info(f"🧾 gateway_ip = {gateway_ip}")
    # logging.info(f"🧾 ip_string = {ip_string}")

    try:
        # Llamada a la API ACTUALIZO LA IP DEL DISPOSITIVO EN LA BASE DE DATOS
        async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientgwIP:
            payload = {
                "ip": ip_string,
                "firmware_version": firmware_version,
                "temp": gw_temp
            }
            response_ip = await clientgwIP.put(gateway_ip, json=payload)
            if response_ip.status_code != 200:
            #     logging.info("✅  Informacion del gateway updatesuccessfully via API")
            # else:
                logging.error(
                    f"🚨 Error Updating gateway data: {response_ip.status_code} - {response_ip.text}")
                return
                
    except httpx.ConnectTimeout:
        logging.error("Connection timed out. The server may be down or unreachable.")
    except httpx.RequestError as e:
        logging.error(f"🚨 An error occurred while requesting {e.request.url!r}.")

    try:
        # Llamada a la tz ACTUALIZO LA IP DEL DISPOSITIVO EN LA BASE DE DATOS
        async with httpx.AsyncClient(cookies=cookies, timeout=60.0) as clientgwTZ:
            response_tz = await clientgwTZ.put(gateway_tz, json={"tz": timezone})
            if response_tz.status_code != 200:
            #     logging.info("✅  TZ updatesuccessfully via API")
            # else:
                logging.error(
                    f"🚨 Error Updating TZ data: {response_tz.status_code} - {response_tz.text}")
                return
                
    except httpx.ConnectTimeout:
        logging.error("Connection timed out. The server may be down or unreachable.")
    except httpx.RequestError as e:
        logging.error(f"🚨 An error occurred while requesting {e.request.url!r}.")

    widnode_by_gw = f"{API_URL}/widnodes/gw/{WIDNODE_GW}"
    
    # Llamada a la API OBTENGO LA LISTA DE NODOS VINCULADOS
    async with httpx.AsyncClient(cookies=cookies) as clientWeb:
        response_widnode = await clientWeb.get(widnode_by_gw)

        if response_widnode.status_code == 200:
            data_widnode = response_widnode.json()
            WIDNODE = [item['widnode_id'] for item in data_widnode]
            logging.info(f"🧾 WIDNODE IDs = {WIDNODE}")
        else:
            logging.error(f" 🚨 Failed to fetch widnode_id list for gw_id {WIDNODE_GW}: {response_widnode.status_code}")
            return

    # ***************************************
    # Llamada A PROCESAR CADA NODO
    # ***************************************
    for device_address in WIDNODE:
        logging.info(f"*********************{device_address}******************************")
        logging.info(f"********************************************************************")
        await process_widnode(device_address)
        logging.info(f"********************************************************************")


async def watchdog_task():
    """Tarea independiente que patea el watchdog de systemd periódicamente."""
    global notifier
    if notifier is None:
        return
    # Intervalo de pateo: mitad de WATCHDOG_USEC (o 10s si no está seteado)
    wd_usec = int(os.environ.get("WATCHDOG_USEC", "0") or "0")
    interval = max(5.0, wd_usec / 2_000_000.0) if wd_usec else 10.0
    while True:
        try:
            notifier.notify("WATCHDOG=1")
        except Exception:
            pass
        await asyncio.sleep(interval)
def kick():
    """Patea el watchdog de systemd de forma inmediata (seguro si notifier no existe)."""
    global notifier
    if notifier:
        try:
            notifier.notify("WATCHDOG=1")
        except Exception:
            pass

# Función principal que contiene tu lógica actual
async def main_loop():
    global events, token,notifier

    # ✅ Inicialización segura de eventos y locks
    events = WidnodeEvents()
    rms_lock = asyncio.Lock()
    measurement_ext_lock = asyncio.Lock()


    
    # ✅ Guardar los locks en globales si otros bloques los necesitan
    globals()["rms_lock"] = rms_lock
    globals()["measurement_ext_lock"] = measurement_ext_lock

    email = os.getenv("EMAIL")
    password = os.getenv("PASSWORD")
    
    # Paso 1: Autenticación
    token = await login(email, password)
    # logging.info(f"token: ${token}")
    if not token:
        logging.error("🚨 Unable to log in. Exiting.")
        return

    token = token.lstrip("$")

    # === systemd watchdog: READY + tarea de latidos ===
    notifier = SystemdNotifier()
    try:
        notifier.notify("READY=1")
        asyncio.create_task(watchdog_task())
    except Exception as e:
        logging.warning(f"Watchdog systemd no disponible: {e}")

    _load_last_seen()  # <-- NUEVO: carga cache RPA al inicio

    # === Iniciar Agent BlueZ para passkey automático ===
    try:
        await start_bt_agent()
    except Exception as e:
        logging.error(f"[AGENT] Error iniciando Agent BlueZ: {e}")

    logging.info("🔁 Iniciando bucle principal widnode...")

    while True:
        start_time = time.time()
        
        try:
            if await should_restart_adapter():
                restart_bluetooth(logging)
            await process_devices()  # Llama a la función principal de tu script
        except Exception as e:
            logging.error(f"🚨 Error en la ejecución del proceso principal: {e}")

        # === NUEVO: liberar conexiones BLE pendientes en el host ===
        try:
            await disconnect_all_devices()
        except Exception as e:
            logging.warning(f"⚠️ No se pudo forzar desconexión inicial: {e}")


        # Calcula el tiempo que tomó ejecutar el proceso
        elapsed_time = time.time() - start_time
        wait_time = max(0, 300 - elapsed_time)  # 1200 segundos = 20 minutos

        if wait_time > 0:
            logging.info(
                f"⏱️ Esperando {wait_time} segundos para la siguiente ejecución...")
            await asyncio.sleep(wait_time)
        else:
            logging.info(
                "🏁 Reiniciando inmediatamente debido al tiempo de ejecución prolongado...")


# Ejecutar ambas pruebas de conexión
if __name__ == "__main__":
    import importlib.metadata, logging, asyncio

     # Log de versión de pymodbus
    try:
        logging.info(f"pymodbus version: {importlib.metadata.version('pymodbus')}")
    except Exception:
        logging.info("pymodbus no instalado en este intérprete")

    # Construís el servidor, pero NO lo arrancás todavía
    try:
        ms = get_modbus_server_config()
        modbus_srv = GatewayModbusServer(
            bind_host=ms["bind"],
            port=ms["port"],
            unit_id=ms["unit_id"],
            mapping=Map(base=ms["base"], stride=ms["stride"], max_index=ms["max_index"])
        )
    except Exception as e:
        logging.error(f"MODBUS SERVER deshabilitado: {e}")
        modbus_srv = None

    async def entry():
        # Ahora sí: dentro del loop
        if modbus_srv is not None:
            await modbus_srv.start()
            logging.info(
                f"Modbus SERVER escuchando en {ms['bind']}:{ms['port']} "
                f"base={ms['base']} stride={ms['stride']} max_index={ms['max_index']}"
            )
        await main_loop()

    asyncio.run(entry())

    # try:
    #     loop = asyncio.new_event_loop()
    #     asyncio.set_event_loop(loop)
    #     loop.run_until_complete(main_loop())
    #     loop.close()
    # finally:
    #     logging.info("bey bey...")
